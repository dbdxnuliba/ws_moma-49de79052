ridgeback
======

Common packages for Ridgeback, including messages and robot description. These are packages relevant
to all Ridgeback workspaces, whether simulation, desktop, or on the robot's own headless PC.
