# ROS packages for the ABB YuMi (IRB14000) robot



For documentation, and instructions on how to install and employ this package, check [our wiki](https://github.com/kth-ros-pkg/yumi/wiki).
